LostValley skybox is free for use but can't be sold for profit or altered in any way.(http://www.redsorceress.com/skybox.html)
LongMattedGrass texture found at (http://www.spiralgraphics.biz)
CrossBow & Texture are creative commons found on (http://www.OpenGameArt.org)
Crosshair is considered public domain.