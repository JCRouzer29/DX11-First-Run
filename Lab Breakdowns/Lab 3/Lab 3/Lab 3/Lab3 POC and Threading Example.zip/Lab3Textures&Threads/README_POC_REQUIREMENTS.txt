To get this POC you must have the following:

Textured Cube.
Working 3D Camera.
Texture Loading MUST be on a seperate thread.
Cube rendering MUST use a "deferred" context.

0.5 POC points for the cube and Texture
1 Full POC point if you also have the deferred context and a seperate thread.